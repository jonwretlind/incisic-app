<!-- ===== THIS IS THE OUTPUT OF THE CALCULATOR ===== -->
<div class="calwrapper container">
	<div class="tab-content">
		<div class="tab-pane active" id="stocks">
			<div class="caloutput container">Loading Data....</div>
		</div>
		<div class="tab-pane" id="bonds">
			<div class="caloutputBonds container"></div>
		</div>
		<div class="tab-pane" id="treas">
			<div class="caloutputTreas container"></div>
		</div>
		<div class="tab-pane" id="ironlaw">
			<div class="caloutputIronLaw container"></div>
		</div>
		<div class="tab-pane" id="blackbox">
			<div class="caloutputBlackBox container"></div>
		</div>
	</div>
</div><!-- // end .calwrapper -->