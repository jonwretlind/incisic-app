// +++++++++++++++++++++++ //
// ++ Global Variables  ++ //
// +++++++++++++++++++++++ //
//var presVal = 0;
window.$ = jQuery;

var annPay;
var mngFee, intRate;
var startYear = 1963;
var numYears;
var BOY;
var myCalcPVonIR;
var actROR;
var IL;
var ILPC;
var ILVal;
var checkedUsePortfolio, checkedStocks, checkedBonds, checkedTreas, percentStocks, percentBonds, percentTreas;
var loggedInState = false;
var calcName, actv;
var theData;
var EconData = new Array();



