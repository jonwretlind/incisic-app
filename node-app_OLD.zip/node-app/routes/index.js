// first structure

module.exports = {
  routes: require('./routes')
}
